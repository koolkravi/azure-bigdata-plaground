var config = {}

config.endpoint = "<cosmosdb>.gremlin.cosmosdb.azure.com";
config.primaryKey = "abcdefg1234567==";
config.database = "GraphDB"
config.collection = "EmployeeGraph"

module.exports = config;